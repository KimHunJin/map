package dxmnd.com.zigbang.java.Object.gson;

/**
 * Created by HunJin on 2017-03-12.
 */

public class Size {
    public String base;
    public String selected;
}
