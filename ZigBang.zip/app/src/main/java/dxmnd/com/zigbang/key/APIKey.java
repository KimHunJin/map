package dxmnd.com.zigbang.key;

/**
 * Created by HunJin on 2017-03-09.
 */

public class APIKey {
    public final static String API_KEY = "d5e81e3641f2350b471915145adb63ca";
}
