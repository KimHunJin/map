package dxmnd.com.zigbang.java.Object.gson;

import com.google.gson.annotations.SerializedName;

/**
 * Created by HunJin on 2017-03-12.
 */

public class Large {
    @SerializedName("xxxh")
    public Size size;
}
